const express = require("express");
const mongoose = require("mongoose");
const multer = require("multer");
const path = require("path");

const app = express();

// MongoDB connect
mongoose.connect("mongodb://127.0.0.1:27017/fileDB")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

// Schema
const FileSchema = new mongoose.Schema({
  filename: String,
  contentType: String,
  data: Buffer
});

const File = mongoose.model("File", FileSchema);

// Multer (store in memory)
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Serve HTML
app.use(express.static(__dirname));

// Upload route
app.post("/upload", upload.single("file"), async (req, res) => {
  try {
    const newFile = new File({
      filename: req.file.originalname,
      contentType: req.file.mimetype,
      data: req.file.buffer
    });

    await newFile.save();
    res.send("File uploaded successfully!");
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Get file
app.get("/file/:id", async (req, res) => {
  try {
    const file = await File.findById(req.params.id);

    if (!file) return res.send("File not found");

    res.contentType(file.contentType);
    res.send(file.data);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Start server
app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});