const greet = require('./index');

console.log(greet('Sahithi')); // Hello, Sahithi!